[MagicaVoxel : 8-bit Voxel Editor & Renderer created by ephtracy]
================================
date    : 12/28/2020

version : 0.99.6.3

os      : win32, win64, MacOS 10.7+

website : https://ephtracy.github.io/

twitter : @ ephtracy

[Credits]
================================
Intel® Open Image Denoise : https://openimagedenoise.github.io
HDRi : HDRI-Hub Free Samples : https://www.hdri-hub.com/hdrishop/freesamples
Icon : Font Awesome Free Version : https://fontawesome.com
Icon : Google Material Design : https://material.io/tools/icons/?style=baseline
Icon : Ionicons : https://ionicons.com